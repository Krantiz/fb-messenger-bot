<?php

namespace IndianSuperLeague;

use Illuminate\Database\Eloquent\Model;

class Player extends Model
{
    protected $table = 'players';
}
