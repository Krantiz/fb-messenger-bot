<?php

namespace IndianSuperLeague\Events;

abstract class Event
{
    //
}
