<?php

use Illuminate\Database\Seeder;

class PlayersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('players')->delete();

            //Atletico de Kolkata
        DB::table('players')->insert(
            array([
                'name' => 'AMRINDER SINGH',
                'about' => 'A product of the Punjab government-run Sports Wing Academy, this Mahilpur lad started as a striker before his first coach Yarvinder Singh, seeing his impressive build, decided to push him to goalkeeping, something that proved a turning point in his career. ',
                'url' => 'http://www.indiansuperleague.com/atletico-de-kolkata/squad/goalkeeper-3997-amrinder-singh-playerprofile',
                'nationality' => 'Indian',
                'position' => 'GOALKEEPER',
                'player_picture' => 'http://images.indiansuperleague.com/images/team-micro/squad-widget/3997.png'
                ],
            	[
                'name' => 'JUAN JESUS CALATAYUD SÁNCHEZ',
                'about' => 'Juan Jesús Calatayud Sánchez came through the youth ranks at Malaga CF. After spending the initial phase of his career with Malaga B team and lower division Spanish teams, Juan Calatayud broke into the senior team and made 36 La Liga appearances between 2003-05.',
                'url' => 'http://www.indiansuperleague.com/atletico-de-kolkata/squad/goalkeeper-19122-juan-jesus-calatayud-sanchez-playerprofile',
                'nationality' => 'SPAIN',
                'position' => 'GOALKEEPER',
                'player_picture' => 'http://images.indiansuperleague.com/images/team-micro/squad-widget/19122.png'
                ])
        );

        //Chennaiyin FC
        DB::table('players')->insert(
           array([
                'name' => 'APOULA EDIMA EDEL BETE',
                'about' => 'The Cameroon-born goalkeeper joined Pyunik Yerevan, Armenia’s most successful club as a 16-year-old. He won the league in each of his three-and-a-half seasons there, before moving to Europe, first to Rapid Bucharest and then to French giants Paris Saint-Germain. ',
                'url' => 'http://www.indiansuperleague.com/chennaiyin-fc/squad/goalkeeper-6582-apoula-edima-edel-bete-playerprofile',
                'nationality' => 'ARMENIA',
                'position' => 'GOALKEEPER',
                'player_picture' => 'http://images.indiansuperleague.com/images/team-micro/squad-widget/6582.png'
                ],
           		[
                'name' => 'KARANJIT SINGH',
                'about' => 'Former national coach Sukhwinder Singh spotted Karanjit when he was just 15. JCT signed him in 2004 and he spent six seasons there. Karanjit eventually found his way to Salgaocar and helped the club to an I-League triumph in the 2010-11 season.',
                'url' => 'http://www.indiansuperleague.com/chennaiyin-fc/squad/goalkeeper-13366-karanjit-singh-playerprofile',
                'nationality' => 'Indian',
                'position' => 'GOALKEEPER',
                'player_picture' => 'http://images.indiansuperleague.com/images/team-micro/squad-widget/13366.png'
                ])
        );

        //Delhi Dynamos FC
        DB::table('players')->insert(
            array([
                'name' => 'ROBERTO CARLOS',
                'about' => 'Probably one of the best left backs in the history of the beautiful game, Roberto Carlos is known for his trademark free kicks and overlapping runs. The Carlos story began with stints at Sao Jao, Atletico Mineiro and Palmeiras in Brazil. As a 19 year old his prodigious talent was acknowledged by his call up to the Brazil Senior side.',
                'url' => 'http://www.indiansuperleague.com/delhi-dynamos-fc/squad/defender-21023-roberto-carlos-playerprofile',
                'nationality' => 'BRAZIL',
                'position' => 'Defender',
                'player_picture' => 'http://images.indiansuperleague.com/images/team-micro/squad-widget/21023.png'
                ],
            	[
                'name' => 'ANTONIO DOBLAS SANTANA',
                'about' => 'Alessandro Del Piero Ufficiale OMRI is an Italian former professional footballer who played as a deep-lying forward. In 2015, he worked as a pundit for Sky Sport Italia.',
                'url' => 'http://www.indiansuperleague.com/delhi-dynamos-fc/squad/goalkeeper-15787-antonio-doblas-santana-playerprofile',
                'nationality' => 'Spain',
                'position' => 'GOALKEEPER',
                'player_picture' => 'http://images.indiansuperleague.com/images/team-micro/squad-widget/15787.png'
                ])
        );

        //FC Goa
        DB::table('players')->insert(
            array([
                'name' => 'Luis Barreto',
                'about' => 'Luis Xavier Barreto is an Indian footballer who plays as a goalkeeper for East Bengal F.C. in the I-League',
                'url' => 'http://www.indiansuperleague.com/fc-goa/squad/goalkeeper-10633-luis-xavier-barreto-playerprofile',
                'nationality' => 'Indian',
                'position' => 'Goalkeeper',
                'player_picture' => 'http://images.indiansuperleague.com/images/team-micro/squad-widget/10633.png'
                ],
            	[
                'name' => 'Lucio Lucio',
                'about' => 'Lucimar Ferreira da Silva, commonly known as Lúcio, is a Brazilian footballer who plays for FC Goa of the Indian Super League as a central defender. He is a strong defender with good aerial play, who also adds presence in the attack.',
                'url' => 'http://www.indiansuperleague.com/fc-goa/squad/defender-19165-lucio-playerprofile',
                'nationality' => 'Brazil',
                'position' => 'Defender',
                'player_picture' => 'http://images.indiansuperleague.com/images/team-micro/squad-widget/19165.png'
                ])
        );

        //FC Pune City
        DB::table('players')->insert(
            array([
                'name' => 'BIKASH JAIRU',
                'about' => 'Another talent scouted by the “ Search for more Bhaichungs” scheme launched by the Govt. , Jairu was initially inducted into the Sports Hostel in Namchi before moving to ONGC FC who offered him a contract in 2008. After the stint with ONGC, he moved back Shillong, to join Rangdajied United FC.',
                'url' => 'http://www.indiansuperleague.com/fc-pune-city/squad/midfielder-19135-bikash-jairu-playerprofile',
                'nationality' => 'Indian',
                'position' => 'MIDFIELDER',
                'player_picture' => 'http://images.indiansuperleague.com/images/team-micro/squad-widget/19135.png'
                ],
            	[
                'name' => 'DIDIER ZOKORA',
                'about' => 'After starting his career with an Ivorian club Mimosas, he moved to Belgium and Zokora played over 100 matches for Belgian club Racing Genk, including a 1-1 draw against Real Madrid in the Champions League 2002-03.',
                'url' => 'http://www.indiansuperleague.com/fc-pune-city/squad/midfielder-1498-didier-zokora-playerprofile',
                'nationality' => 'IVORY COAST',
                'position' => 'MIDFIELDER',
                'player_picture' => 'http://images.indiansuperleague.com/images/team-micro/squad-widget/1498.png'
                ])
        );

        //Kerala Blasters FC
        DB::table('players')->insert(
            array([
                'name' => 'SANDIP NANDY',
                'about' => 'Goalkeepers often have a long shelf life and the 40-year-old gloveman from West Bengal best exemplifies this maxim in the Indian context. Sandip Nandy’s debut in big time football with Mohun Bagan in 1999 was a winning one with the boatmen winning the NFL.',
                'url' => 'http://www.indiansuperleague.com/kerala-blasters-fc/squad/goalkeeper-10639-sandip-nandy-playerprofile',
                'nationality' => 'Indian',
                'position' => 'GOALKEEPER',
                'player_picture' => 'http://images.indiansuperleague.com/images/team-micro/squad-widget/10639.png'
                ],
            	[
                'name' => 'CHRIS DAGNALL',
                'about' => 'The Liverpool born striker started his career at the age of 13 with Tranmere Rovers and scored his first goal for the club in a loss to Luton Town. It was a sign of many more goals to come as the forward would go onto score 112 goals in 414 club appearances for clubs such as Rochdale, Scunthorpe, Barnsley, Bradford City, Leyton Orient etc.',
                'url' => 'http://www.indiansuperleague.com/kerala-blasters-fc/squad/forward-18803-chris-dagnall-playerprofile',
                'nationality' => 'ENGLAND',
                'position' => 'FORWARD',
                'player_picture' => 'http://images.indiansuperleague.com/images/team-micro/squad-widget/18803.png'
                ])
        );

        //Mumbai City FC
        DB::table('players')->insert(
            array([
                'name' => 'Subrata Paul',
                'about' => 'Subrata Pal is an Indian professional footballer who currently plays for Indian Super League side NorthEast United, on loan from DSK Shivajians in the I-League.',
                'url' => 'http://www.indiansuperleague.com/mumbai-city-fc/squad/goalkeeper-10767-subrata-paul-playerprofile',
                'nationality' => 'Indian',
                'position' => 'Goalkeeper',
                'player_picture' => 'http://images.indiansuperleague.com/images/team-micro/squad-widget/10767.png'
                ],
            	[
                'name' => 'JUAN AGUILERA NUNEZ',
                'about' => 'A native of Madrid, Spain, Juan Aguilera Nunez learned his craft with the reserve team of Getafe FC followed by a spell at CDA Navalcamero. Subsequently, he spent 3 years in the Spanish third tier side CD Leganes.',
                'url' => 'http://www.indiansuperleague.com/mumbai-city-fc/squad/midfielder-19149-juan-aguilera-nunez-playerprofile',
                'nationality' => 'SPAIN',
                'position' => 'MIDFIELDER',
                'player_picture' => 'http://images.indiansuperleague.com/images/team-micro/squad-widget/19149.png'
                ])
        );

        //Northeast United FC
        DB::table('players')->insert(
            array([
                'name' => 'GENNARO BRACIGLIANO',
                'about' => 'Rising through the youth ranks at AS Nancy, Bracigliano made a memorable first-team debut as an 18-year-old, keeping a clean sheet against giants PSG. ',
                'url' => 'http://www.indiansuperleague.com/northeast-united-fc/squad/goalkeeper-10675-gennaro-bracigliano-playerprofile',
                'nationality' => 'FRANCE',
                'position' => 'GOALKEEPER',
                'player_picture' => 'http://images.indiansuperleague.com/images/team-micro/squad-widget/10675.png'
                ],
            	[
                'name' => 'LALTHUAMMAWIA RALTE',
                'about' => 'Lalthuammawia Ralte began his career with Shillong Lajong and has come a long way from his humble beginnings in Mizoram to become the first pick in the 2015 Hero Indian Super League Draft for North East United FC.',
                'url' => 'http://www.indiansuperleague.com/northeast-united-fc/squad/goalkeeper-19126-lalthuammawia-ralte-playerprofile',
                'nationality' => 'Indian',
                'position' => 'GOALKEEPER',
                'player_picture' => 'http://images.indiansuperleague.com/images/team-micro/squad-widget/19126.png'
                ])
        );
    }
}
