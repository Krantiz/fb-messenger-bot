<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class TeamsForeignKeyTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('teams', function(Blueprint $table) {
            $table->unsignedInteger('captain_id')->nullable()->after('photos');
            $table->unsignedInteger('marquee_player_id')->nullable()->after('captain_id');
        });
        
        Schema::table('teams', function($table) {
            $table->foreign('captain_id')->references('id')->on('players')->onDelete('restrict')->onUpdate('cascade');
            $table->foreign('marquee_player_id')->references('id')->on('players')->onDelete('restrict')->onUpdate('cascade');
        });


        Schema::table('players', function(Blueprint $table) {
            $table->unsignedInteger('team_id')->nullable()->after('player_picture');
          
        });
        
        Schema::table('players', function($table) {
            $table->foreign('team_id')->references('id')->on('teams')->onDelete('restrict')->onUpdate('cascade');
           
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('teams', function(Blueprint $table) {
            $table->dropForeign('teams_captain_id_foreign');
            $table->dropForeign('teams_marquee_player_id_foreign');
            
            $table->dropColumn(['captain_id']);
            $table->dropColumn(['marquee_player_id']);
        });
        
        Schema::table('players', function(Blueprint $table) {
            $table->dropForeign('players_team_id_foreign');
            $table->dropColumn(['team_id']);
        });
    }
}
