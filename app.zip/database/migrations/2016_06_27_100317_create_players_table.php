<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePlayersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('players', function (Blueprint $table) { 
            $table->increments('id')->unsigned();
            $table->string('name', 255);
            $table->text('about');
            $table->string('url', 255);
            $table->string('nationality', 255);
            $table->string('position', 255);
            $table->string('player_picture', 255);
            
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('players');
    }
}
