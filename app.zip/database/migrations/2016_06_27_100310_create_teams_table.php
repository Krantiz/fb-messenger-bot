<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTeamsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('teams', function (Blueprint $table) { 
            $table->increments('id');
            $table->string('name', 255);
            $table->text('about');
            $table->string('url', 255);
            $table->string('owner', 255);
            $table->string('mascot', 255); 
            $table->string('manager', 255);
            $table->string('brand_ambassador', 255);
            $table->string('photos', 255);
        });

        
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('teams');
    }
}
