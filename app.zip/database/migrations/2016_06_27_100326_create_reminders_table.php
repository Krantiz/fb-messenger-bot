<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRemindersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('reminders', function (Blueprint $table) { 
            $table->increments('id');
            $table->integer('apiai_response_id')->unsigned();
            $table->text('data');
            $table->timestamp('remind_at');
        });

        Schema::table('reminders', function($table) {
            $table->foreign('apiai_response_id')->references('id')->on('apiai_responses')->onDelete('restrict')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('reminders');
    }
}
