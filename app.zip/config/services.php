<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Stripe, Mailgun, Mandrill, and others. This file provides a sane
    | default location for this type of information, allowing packages
    | to have a conventional place to find your various credentials.
    |
    */

    'mailgun' => [
        'domain' => env('MAILGUN_DOMAIN'),
        'secret' => env('MAILGUN_SECRET'),
    ],

    'ses' => [
        'key' => env('SES_KEY'),
        'secret' => env('SES_SECRET'),
        'region' => 'us-east-1',
    ],

    'sparkpost' => [
        'secret' => env('SPARKPOST_SECRET'),
    ],

    'stripe' => [
        'model' => IndianSuperLeague\User::class,
        'key' => env('STRIPE_KEY'),
        'secret' => env('STRIPE_SECRET'),
    ],

    'facebook' => [
        'verify_token'      => 'this_better_work_as_I_am_expecting',
        'page_access_token' => 'EAANoFWIttK0BAIOLWqXjmAKOloDYAlbga8CXwD9vpzyE4jbxXrsZAVyKEyTnCdgBCmrbweQYtrskrP3irthsDs6Fi3SZCLV6kkWM7lrBTCKw90bIchhZAqMSfyXkZAUQq7o05KokZCV5EzemZC9IMlwNO4ZAEdxmNtxUZCZCKmukItgZDZD',

        'text_character_limit' => 319,

        'failed_message'    => 'Sorry, but I am not able to comprehend what you are saying! I am just a bot, you see! Could you ask me that in another way, please?'

    ],

    'apiai' => [
        'client_access_token' => '9ee2943224af4297b01bcdc00287b736'
    ]

];
